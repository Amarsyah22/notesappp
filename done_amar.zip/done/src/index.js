import './style/style.css';

import '../data/app-bar.js';
import '../data/data.js';
import '../data/footer-bar.js';
import '../data/note-item.js';